import BmrReducer from './bmr_reducer'
import { combineReducers } from 'redux';

export const rootReducer = combineReducers({ BmrReducer: BmrReducer })
