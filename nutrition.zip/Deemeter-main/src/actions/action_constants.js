export const actionConstants={
    INIT_BMR: 'INIT_BMR',
    MODIFY_BMR: 'MODIFY_BMR'
}